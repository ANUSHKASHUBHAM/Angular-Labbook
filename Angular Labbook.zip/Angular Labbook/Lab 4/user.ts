export interface user{
    id: Number;
    title: String;
    author: String;
    year: Number;
}