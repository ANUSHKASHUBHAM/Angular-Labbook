import { FilterPipe } from './filter-pipe';

describe('FilterPipe', () => {
  it('should create an instance', () => {
    expect(new FilterPipe()).toBeTruthy();
  });
});